// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/**
 * @title CPMM
 * @dev A simple constant-product market maker for TokenA and TokenB.
 * Supports liquidity provision, liquidity removal, and token swaps.
 */
contract CPMM {
    IERC20 public immutable tokenA;
    IERC20 public immutable tokenB;

    uint256 public reserveA;
    uint256 public reserveB;

    uint256 public totalLiquidity;
    mapping(address => uint256) public liquidityOf;

    // 0.3% fee => 997/1000 of input amount is used in pricing
    uint256 public constant FEE_NUMERATOR = 997;
    uint256 public constant FEE_DENOMINATOR = 1000;

    event LiquidityAdded(
        address indexed provider,
        uint256 amountA,
        uint256 amountB,
        uint256 liquidityMinted
    );

    event LiquidityRemoved(
        address indexed provider,
        uint256 amountA,
        uint256 amountB,
        uint256 liquidityBurned
    );

    event SwapAForB(
        address indexed user,
        uint256 amountAIn,
        uint256 amountBOut
    );

    event SwapBForA(
        address indexed user,
        uint256 amountBIn,
        uint256 amountAOut
    );

    constructor(address _tokenA, address _tokenB) {
        require(_tokenA != address(0) && _tokenB != address(0), "Zero address");
        require(_tokenA != _tokenB, "Tokens must differ");

        tokenA = IERC20(_tokenA);
        tokenB = IERC20(_tokenB);
    }

    /**
     * @dev Add liquidity in the correct pool ratio.
     * For the first provider, any positive amounts are allowed.
     * For later providers, the deposited ratio must match current reserves.
     */
    function addLiquidity(uint256 amountA, uint256 amountB)
        external
        returns (uint256 liquidityMinted)
    {
        require(amountA > 0 && amountB > 0, "Amounts must be > 0");

        if (totalLiquidity == 0) {
            require(tokenA.transferFrom(msg.sender, address(this), amountA), "TokenA transfer failed");
            require(tokenB.transferFrom(msg.sender, address(this), amountB), "TokenB transfer failed");

            liquidityMinted = sqrt(amountA * amountB);
            require(liquidityMinted > 0, "Insufficient liquidity minted");
        } else {
            require(amountA * reserveB == amountB * reserveA, "Wrong token ratio");

            require(tokenA.transferFrom(msg.sender, address(this), amountA), "TokenA transfer failed");
            require(tokenB.transferFrom(msg.sender, address(this), amountB), "TokenB transfer failed");

            liquidityMinted = (amountA * totalLiquidity) / reserveA;
            require(liquidityMinted > 0, "Insufficient liquidity minted");
        }

        liquidityOf[msg.sender] += liquidityMinted;
        totalLiquidity += liquidityMinted;

        _updateReserves();

        emit LiquidityAdded(msg.sender, amountA, amountB, liquidityMinted);
    }

    /**
     * @dev Remove liquidity and receive proportional shares of TokenA and TokenB.
     */
    function removeLiquidity(uint256 liquidityBurned)
        external
        returns (uint256 amountA, uint256 amountB)
    {
        require(liquidityBurned > 0, "Liquidity must be > 0");
        require(liquidityOf[msg.sender] >= liquidityBurned, "Not enough liquidity");

        amountA = (liquidityBurned * reserveA) / totalLiquidity;
        amountB = (liquidityBurned * reserveB) / totalLiquidity;

        liquidityOf[msg.sender] -= liquidityBurned;
        totalLiquidity -= liquidityBurned;

        require(tokenA.transfer(msg.sender, amountA), "TokenA transfer failed");
        require(tokenB.transfer(msg.sender, amountB), "TokenB transfer failed");

        _updateReserves();

        emit LiquidityRemoved(msg.sender, amountA, amountB, liquidityBurned);
    }

    /**
     * @dev Swap TokenA for TokenB using the constant-product formula with fee.
     * minAmountBOut provides slippage protection.
     */
    function swapAForB(uint256 amountAIn, uint256 minAmountBOut)
        external
        returns (uint256 amountBOut)
    {
        require(amountAIn > 0, "Input must be > 0");
        require(reserveA > 0 && reserveB > 0, "No liquidity");

        amountBOut = getAmountOut(amountAIn, reserveA, reserveB);
        require(amountBOut >= minAmountBOut, "Slippage too high");

        require(tokenA.transferFrom(msg.sender, address(this), amountAIn), "TokenA transfer failed");
        require(tokenB.transfer(msg.sender, amountBOut), "TokenB transfer failed");

        _updateReserves();

        emit SwapAForB(msg.sender, amountAIn, amountBOut);
    }

    /**
     * @dev Swap TokenB for TokenA using the constant-product formula with fee.
     * minAmountAOut provides slippage protection.
     */
    function swapBForA(uint256 amountBIn, uint256 minAmountAOut)
        external
        returns (uint256 amountAOut)
    {
        require(amountBIn > 0, "Input must be > 0");
        require(reserveA > 0 && reserveB > 0, "No liquidity");

        amountAOut = getAmountOut(amountBIn, reserveB, reserveA);
        require(amountAOut >= minAmountAOut, "Slippage too high");

        require(tokenB.transferFrom(msg.sender, address(this), amountBIn), "TokenB transfer failed");
        require(tokenA.transfer(msg.sender, amountAOut), "TokenA transfer failed");

        _updateReserves();

        emit SwapBForA(msg.sender, amountBIn, amountAOut);
    }

    /**
     * @dev Pricing formula with 0.3% fee.
     */
    function getAmountOut(
        uint256 amountIn,
        uint256 reserveIn,
        uint256 reserveOut
    ) public pure returns (uint256 amountOut) {
        require(amountIn > 0, "Amount in must be > 0");
        require(reserveIn > 0 && reserveOut > 0, "Invalid reserves");

        uint256 amountInWithFee = amountIn * FEE_NUMERATOR;
        uint256 numerator = amountInWithFee * reserveOut;
        uint256 denominator = reserveIn * FEE_DENOMINATOR + amountInWithFee;

        amountOut = numerator / denominator;
    }

    /**
     * @dev Return current reserves.
     */
    function getReserves() external view returns (uint256, uint256) {
        return (reserveA, reserveB);
    }

    /**
     * @dev Return TokenA price in units of TokenB, scaled by 1e18.
     */
    function getPriceAinB() external view returns (uint256) {
        require(reserveA > 0, "No reserveA");
        return (reserveB * 1e18) / reserveA;
    }

    /**
     * @dev Return TokenB price in units of TokenA, scaled by 1e18.
     */
    function getPriceBinA() external view returns (uint256) {
        require(reserveB > 0, "No reserveB");
        return (reserveA * 1e18) / reserveB;
    }

    function _updateReserves() internal {
        reserveA = tokenA.balanceOf(address(this));
        reserveB = tokenB.balanceOf(address(this));
    }

    /**
     * @dev Integer square root helper used for initial liquidity minting.
     */
    function sqrt(uint256 y) internal pure returns (uint256 z) {
        if (y > 3) {
            z = y;
            uint256 x = y / 2 + 1;
            while (x < z) {
                z = x;
                x = (y / x + x) / 2;
            }
        } else if (y != 0) {
            z = 1;
        }
    }
}