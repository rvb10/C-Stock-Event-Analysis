// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/**
 * @title TokenB
 * @dev ERC-20 token used as the second side of the CPMM trading pair.
 * The initial supply is minted to the deployer at deployment time.
 */
contract TokenB is ERC20 {
    constructor(uint256 initialSupply) ERC20("Token B", "TKB") {
        _mint(msg.sender, initialSupply);
    }
}