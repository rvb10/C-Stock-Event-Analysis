// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// Chainlink interface for reading price feeds
interface AggregatorV3Interface {
    function decimals() external view returns (uint8);
    function latestRoundData()
        external
        view
        returns (
            uint80 roundId,
            int256 answer,
            uint256 startedAt,
            uint256 updatedAt,
            uint80 answeredInRound
        );
}

// Minimal interface to read AMM spot price
interface ICPMM {
    function getPriceAinB() external view returns (uint256);
    function getPriceBinA() external view returns (uint256);
    function getReserves() external view returns (uint256, uint256);
}

/**
 * @title CPMMOracle
 * @dev Reads the Chainlink ETH/USD price feed on Sepolia and compares it
 *      against the AMM spot price from the deployed CPMM contract.
 *      Used to identify arbitrage opportunities and measure price deviation.
 *
 * Chainlink ETH/USD feed on Sepolia:
 *   0x694AA1769357215DE4FAC081bf1f309aDC325306
 *
 * Methodology:
 *   - "External price"  = Chainlink ETH/USD (scaled to 18 decimals)
 *   - "AMM spot price"  = reserveB / reserveA (already scaled to 1e18 by CPMM)
 *   - "Deviation (bps)" = |external - amm| * 10000 / external
 *   - Arbitrage signal  = deviation > ARB_THRESHOLD_BPS (default: 50 bps = 0.5%)
 */
contract CPMMOracle {

    // ----------------------------------------------------------------
    // State variables
    // ----------------------------------------------------------------

    /// @notice Chainlink ETH/USD aggregator on Sepolia
    AggregatorV3Interface public immutable priceFeed;

    /// @notice The CPMM pool we are monitoring
    ICPMM public immutable cpmm;

    /// @notice Owner of this contract (deployer)
    address public immutable owner;

    /// @notice Arbitrage signal threshold in basis points (1 bp = 0.01%)
    /// Default: 50 bps = 0.5% deviation triggers an arbitrage alert
    uint256 public arbThresholdBps;

    /// @notice Maximum age (seconds) we accept for a Chainlink answer
    /// If the feed hasn't updated within this window we revert as stale
    uint256 public constant STALENESS_THRESHOLD = 3600; // 1 hour

    // ----------------------------------------------------------------
    // Events
    // ----------------------------------------------------------------

    /**
     * @notice Emitted every time getPriceComparison() is called.
     * @param chainlinkPrice  ETH/USD from Chainlink, scaled to 1e18
     * @param ammSpotPrice    TokenA price in TokenB units, scaled to 1e18
     * @param deviationBps    Absolute deviation in basis points
     * @param arbOpportunity  True when deviation >= arbThresholdBps
     */
    event PriceSnapshot(
    uint256 chainlinkPrice,
    uint256 ammSpotPrice,
    uint256 deviationBps,
    bool arbOpportunity
);

    /**
     * @notice Emitted when the owner updates the arb threshold.
     */
    event ThresholdUpdated(uint256 oldBps, uint256 newBps);

    // ----------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------

    /**
     * @param _cpmm    Address of the deployed CPMM contract
     *
     * The Chainlink ETH/USD feed address on Sepolia is hard-coded because
     * it is a well-known, immutable Chainlink deployment:
     *   0x694AA1769357215DE4FAC081bf1f309aDC325306
     */
    constructor(address _cpmm) {
        require(_cpmm != address(0), "Zero address: cpmm");

        // Hard-coded Sepolia ETH/USD Chainlink feed
        priceFeed = AggregatorV3Interface(
            0x694AA1769357215DE4FAC081bf1f309aDC325306
        );

        cpmm          = ICPMM(_cpmm);
        owner         = msg.sender;
        arbThresholdBps = 50; // 0.5% default
    }

    // ----------------------------------------------------------------
    // Core view functions
    // ----------------------------------------------------------------

    /**
     * @notice Fetch the latest ETH/USD price from Chainlink.
     * @dev Reverts if the answer is stale (older than STALENESS_THRESHOLD).
     * @return price  ETH/USD price scaled to 1e18
     */
    function getChainlinkPrice() public view returns (uint256 price) {
        (
            uint80  roundId,
            int256  answer,
            ,
            uint256 updatedAt,
            uint80  answeredInRound
        ) = priceFeed.latestRoundData();

        // Sanity checks recommended by Chainlink docs
        require(answer > 0,                        "Chainlink: negative price");
        require(updatedAt > 0,                     "Chainlink: round not complete");
        require(answeredInRound >= roundId,         "Chainlink: stale round");
        require(
            block.timestamp - updatedAt <= STALENESS_THRESHOLD,
            "Chainlink: price too stale"
        );

        // Chainlink ETH/USD uses 8 decimals; scale up to 1e18
        uint8 feedDecimals = priceFeed.decimals();
        price = uint256(answer) * (10 ** (18 - feedDecimals));
    }

    /**
     * @notice Fetch the AMM spot price of TokenA expressed in TokenB units.
     * @dev Delegates directly to CPMM.getPriceAinB() which returns reserveB/reserveA * 1e18.
     * @return ammPrice  Spot price scaled to 1e18
     */
    function getAMMSpotPrice() public view returns (uint256 ammPrice) {
        ammPrice = cpmm.getPriceAinB();
    }

    /**
     * @notice Compare Chainlink price vs AMM spot price.
     * @dev Also emits a PriceSnapshot event so the comparison is logged on-chain.
     * @return chainlinkPrice  ETH/USD from Chainlink (1e18)
     * @return ammSpotPrice    AMM spot price of A in B (1e18)
     * @return deviationBps    Absolute deviation in basis points
     * @return arbOpportunity  True if deviation >= arbThresholdBps
     */
    function getPriceComparison()
        external
        returns (
            uint256 chainlinkPrice,
            uint256 ammSpotPrice,
            uint256 deviationBps,
            bool    arbOpportunity
        )
    {
        chainlinkPrice = getChainlinkPrice();
        ammSpotPrice   = getAMMSpotPrice();

        deviationBps   = _computeDeviationBps(chainlinkPrice, ammSpotPrice);
        arbOpportunity = deviationBps >= arbThresholdBps;

        emit PriceSnapshot(chainlinkPrice, ammSpotPrice, deviationBps, arbOpportunity);
    }

    /**
     * @notice Read-only version of getPriceComparison (no event emitted).
     *         Useful for frontend polling without spending gas.
     */
    function getPriceComparisonView()
        external
        view
        returns (
            uint256 chainlinkPrice,
            uint256 ammSpotPrice,
            uint256 deviationBps,
            bool    arbOpportunity
        )
    {
        chainlinkPrice = getChainlinkPrice();
        ammSpotPrice   = getAMMSpotPrice();
        deviationBps   = _computeDeviationBps(chainlinkPrice, ammSpotPrice);
        arbOpportunity = deviationBps >= arbThresholdBps;
    }

    /**
     * @notice Returns a full snapshot: reserves + both prices + deviation.
     *         Convenient for the frontend dashboard.
     */
    function getFullSnapshot()
        external
        view
        returns (
            uint256 reserveA,
            uint256 reserveB,
            uint256 chainlinkPrice,
            uint256 ammSpotPrice,
            uint256 deviationBps,
            bool    arbOpportunity
        )
    {
        (reserveA, reserveB) = cpmm.getReserves();
        chainlinkPrice       = getChainlinkPrice();
        ammSpotPrice         = getAMMSpotPrice();
        deviationBps         = _computeDeviationBps(chainlinkPrice, ammSpotPrice);
        arbOpportunity       = deviationBps >= arbThresholdBps;
    }

    // ----------------------------------------------------------------
    // Owner functions
    // ----------------------------------------------------------------

    /**
     * @notice Update the basis-point threshold that triggers an arb signal.
     * @param newBps  New threshold in basis points (e.g. 100 = 1%)
     */
    function setArbThreshold(uint256 newBps) external {
        require(msg.sender == owner, "Only owner");
        require(newBps > 0 && newBps <= 10000, "Invalid bps");
        emit ThresholdUpdated(arbThresholdBps, newBps);
        arbThresholdBps = newBps;
    }

    // ----------------------------------------------------------------
    // Internal helpers
    // ----------------------------------------------------------------

    /**
     * @dev Compute absolute deviation between two prices in basis points.
     *      deviationBps = |a - b| * 10000 / a
     *      Uses the Chainlink price as the reference (denominator).
     */
    function _computeDeviationBps(uint256 a, uint256 b)
        internal
        pure
        returns (uint256)
    {
        if (a == 0) return 0;
        uint256 diff = a > b ? a - b : b - a;
        return (diff * 10_000) / a;
    }
}
