// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/**
 * @title TokenA
 * @dev ERC-20 token used as one side of the CPMM trading pair.
 * The initial supply is minted to the deployer at deployment time.
 */
contract TokenA is ERC20 {
    constructor(uint256 initialSupply) ERC20("Token A", "TKA") {
        _mint(msg.sender, initialSupply);
    }
}