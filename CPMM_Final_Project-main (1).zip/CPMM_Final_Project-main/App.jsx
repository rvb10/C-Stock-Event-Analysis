import { useState, useEffect, useCallback } from "react";
import { ethers } from "ethers";
import { ethers } from "https://esm.sh/ethers@6.7.0";

// ─── Contract Addresses (Sepolia) ───────────────────────────────────────────
const ADDRESSES = {
  tokenA: "0xeA3a8a720a9Cdf4F606Ff44BA8cbde847bd0E532",
  tokenB: "0xEDe845Cef84854EE924BDd53805C20E73A255e02",
  cpmm:   "0x2469B370BB768129F2E2b545A0E0fEBdA75A5541",
  oracle: "0x656C6246Ad2f7bbd9CF7EAEAB15669D9B815e9E9", // replace after deploying CPMMOracle.sol
};

// ─── ABIs (minimal) ─────────────────────────────────────────────────────────
const ERC20_ABI = [
  "function approve(address spender, uint256 amount) returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function balanceOf(address account) view returns (uint256)",
  "function decimals() view returns (uint8)",
];

const CPMM_ABI = [
  "function addLiquidity(uint256 amountA, uint256 amountB) returns (uint256)",
  "function removeLiquidity(uint256 liquidityBurned) returns (uint256, uint256)",
  "function swapAForB(uint256 amountAIn, uint256 minAmountBOut) returns (uint256)",
  "function swapBForA(uint256 amountBIn, uint256 minAmountAOut) returns (uint256)",
  "function getReserves() view returns (uint256, uint256)",
  "function getPriceAinB() view returns (uint256)",
  "function getPriceBinA() view returns (uint256)",
  "function liquidityOf(address) view returns (uint256)",
  "function totalLiquidity() view returns (uint256)",
  "function getAmountOut(uint256 amountIn, uint256 reserveIn, uint256 reserveOut) pure returns (uint256)",
];

const ORACLE_ABI = [
  "function getPriceComparisonView() view returns (uint256 chainlinkPrice, uint256 ammSpotPrice, uint256 deviationBps, bool arbOpportunity)",
  "function getFullSnapshot() view returns (uint256 reserveA, uint256 reserveB, uint256 chainlinkPrice, uint256 ammSpotPrice, uint256 deviationBps, bool arbOpportunity)",
  "function arbThresholdBps() view returns (uint256)",
];

// ─── Helpers ─────────────────────────────────────────────────────────────────
const fmt = (val, decimals = 4) =>
  val !== null && val !== undefined
    ? Number(ethers.formatUnits(val, 18)).toFixed(decimals)
    : "—";

const fmtUSD = (val) =>
  val !== null ? `$${Number(val).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "—";

const shortAddr = (addr) => addr ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : "";

// ─── Styles ──────────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;700;800&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:       #0a0a0f;
    --surface:  #111118;
    --border:   #1e1e2e;
    --border2:  #2a2a3e;
    --accent:   #7fff6e;
    --accent2:  #6ec8ff;
    --accent3:  #ff6e9c;
    --warn:     #ffb86e;
    --text:     #e8e8f0;
    --muted:    #666680;
    --mono:     'Space Mono', monospace;
    --sans:     'Syne', sans-serif;
    --radius:   12px;
    --radius-sm:6px;
  }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    min-height: 100vh;
    overflow-x: hidden;
  }

  /* Grid noise texture overlay */
  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(127,255,110,0.015) 1px, transparent 1px),
      linear-gradient(90deg, rgba(127,255,110,0.015) 1px, transparent 1px);
    background-size: 40px 40px;
    pointer-events: none;
    z-index: 0;
  }

  #root { position: relative; z-index: 1; }

  /* ── Header ── */
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 32px;
    border-bottom: 1px solid var(--border);
    background: rgba(10,10,15,0.9);
    backdrop-filter: blur(12px);
    position: sticky;
    top: 0;
    z-index: 100;
  }
  .logo {
    font-family: var(--sans);
    font-weight: 800;
    font-size: 20px;
    letter-spacing: -0.5px;
  }
  .logo span { color: var(--accent); }
  .logo sub {
    font-size: 10px;
    color: var(--muted);
    font-weight: 400;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-left: 8px;
  }

  .connect-btn {
    font-family: var(--mono);
    font-size: 12px;
    padding: 10px 20px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--accent);
    background: transparent;
    color: var(--accent);
    cursor: pointer;
    transition: all 0.15s;
    letter-spacing: 1px;
  }
  .connect-btn:hover { background: var(--accent); color: var(--bg); }
  .connect-btn.connected {
    border-color: var(--border2);
    color: var(--muted);
  }
  .connect-btn.connected:hover { border-color: var(--accent3); color: var(--accent3); background: transparent; }

  /* ── Main layout ── */
  .main {
    max-width: 1280px;
    margin: 0 auto;
    padding: 32px 24px 80px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
  }

  .full-width { grid-column: 1 / -1; }

  /* ── Cards ── */
  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 24px;
    transition: border-color 0.2s;
  }
  .card:hover { border-color: var(--border2); }

  .card-title {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 2.5px;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .card-title .dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
    box-shadow: 0 0 8px var(--accent);
  }
  .card-title .dot.blue  { background: var(--accent2); box-shadow: 0 0 8px var(--accent2); }
  .card-title .dot.pink  { background: var(--accent3); box-shadow: 0 0 8px var(--accent3); }
  .card-title .dot.warn  { background: var(--warn);    box-shadow: 0 0 8px var(--warn); }

  /* ── Stat grid ── */
  .stat-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
  }
  .stat {
    background: rgba(255,255,255,0.02);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 16px;
  }
  .stat-label {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 1px;
    margin-bottom: 8px;
  }
  .stat-value {
    font-family: var(--mono);
    font-size: 18px;
    font-weight: 700;
    color: var(--text);
  }
  .stat-value.green { color: var(--accent); }
  .stat-value.blue  { color: var(--accent2); }
  .stat-value.pink  { color: var(--accent3); }
  .stat-value.warn  { color: var(--warn); }

  /* ── Oracle panel ── */
  .oracle-row {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr auto;
    gap: 12px;
    align-items: center;
  }
  .oracle-stat { }
  .oracle-label {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 1px;
    margin-bottom: 6px;
  }
  .oracle-value {
    font-family: var(--mono);
    font-size: 20px;
    font-weight: 700;
  }
  .arb-badge {
    padding: 12px 18px;
    border-radius: var(--radius-sm);
    font-family: var(--mono);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1px;
    text-align: center;
    white-space: nowrap;
  }
  .arb-badge.active {
    background: rgba(255,110,156,0.15);
    border: 1px solid var(--accent3);
    color: var(--accent3);
    animation: pulse-pink 2s infinite;
  }
  .arb-badge.inactive {
    background: rgba(127,255,110,0.08);
    border: 1px solid rgba(127,255,110,0.3);
    color: var(--accent);
  }

  @keyframes pulse-pink {
    0%, 100% { box-shadow: 0 0 0 0 rgba(255,110,156,0.4); }
    50%       { box-shadow: 0 0 0 6px rgba(255,110,156,0); }
  }

  /* ── Tabs ── */
  .tabs {
    display: flex;
    gap: 2px;
    background: rgba(255,255,255,0.03);
    border-radius: var(--radius-sm);
    padding: 3px;
    margin-bottom: 20px;
  }
  .tab {
    flex: 1;
    padding: 8px;
    border: none;
    border-radius: 6px;
    background: transparent;
    color: var(--muted);
    font-family: var(--mono);
    font-size: 11px;
    letter-spacing: 1px;
    cursor: pointer;
    transition: all 0.15s;
  }
  .tab.active {
    background: var(--border2);
    color: var(--text);
  }
  .tab:hover:not(.active) { color: var(--text); }

  /* ── Inputs ── */
  .input-group { margin-bottom: 14px; }
  .input-label {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 1px;
    margin-bottom: 6px;
    display: flex;
    justify-content: space-between;
  }
  .input-label span { color: var(--accent2); }
  input[type="text"], input[type="number"] {
    width: 100%;
    background: rgba(255,255,255,0.04);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 12px 14px;
    color: var(--text);
    font-family: var(--mono);
    font-size: 14px;
    outline: none;
    transition: border-color 0.15s;
  }
  input:focus { border-color: var(--accent2); }
  input::placeholder { color: var(--muted); }

  /* ── Buttons ── */
  .btn {
    width: 100%;
    padding: 14px;
    border: none;
    border-radius: var(--radius-sm);
    font-family: var(--mono);
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 2px;
    cursor: pointer;
    transition: all 0.15s;
    text-transform: uppercase;
  }
  .btn-primary {
    background: var(--accent);
    color: var(--bg);
  }
  .btn-primary:hover:not(:disabled) {
    background: #a0ffaa;
    transform: translateY(-1px);
    box-shadow: 0 4px 20px rgba(127,255,110,0.3);
  }
  .btn-blue {
    background: var(--accent2);
    color: var(--bg);
  }
  .btn-blue:hover:not(:disabled) {
    background: #a0e0ff;
    transform: translateY(-1px);
    box-shadow: 0 4px 20px rgba(110,200,255,0.3);
  }
  .btn-pink {
    background: var(--accent3);
    color: var(--bg);
  }
  .btn-pink:hover:not(:disabled) {
    transform: translateY(-1px);
    box-shadow: 0 4px 20px rgba(255,110,156,0.3);
  }
  .btn:disabled {
    opacity: 0.4;
    cursor: not-allowed;
    transform: none !important;
  }
  .btn-outline {
    background: transparent;
    border: 1px solid var(--border2);
    color: var(--muted);
    margin-top: 8px;
  }
  .btn-outline:hover:not(:disabled) { border-color: var(--accent2); color: var(--accent2); }

  /* ── Preview box ── */
  .preview {
    background: rgba(255,255,255,0.02);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    padding: 12px 14px;
    font-family: var(--mono);
    font-size: 12px;
    color: var(--muted);
    margin-bottom: 14px;
    min-height: 44px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .preview strong { color: var(--accent); font-size: 14px; }

  /* ── Transaction feed ── */
  .tx-feed { display: flex; flex-direction: column; gap: 8px; max-height: 320px; overflow-y: auto; }
  .tx-feed::-webkit-scrollbar { width: 4px; }
  .tx-feed::-webkit-scrollbar-track { background: transparent; }
  .tx-feed::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 2px; }

  .tx-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 14px;
    background: rgba(255,255,255,0.02);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    font-family: var(--mono);
    font-size: 11px;
    animation: slide-in 0.3s ease;
  }
  @keyframes slide-in {
    from { opacity: 0; transform: translateX(-8px); }
    to   { opacity: 1; transform: translateX(0); }
  }
  .tx-type {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 700;
    white-space: nowrap;
  }
  .tx-type.swap    { background: rgba(110,200,255,0.15); color: var(--accent2); }
  .tx-type.add     { background: rgba(127,255,110,0.15); color: var(--accent); }
  .tx-type.remove  { background: rgba(255,184,110,0.15); color: var(--warn); }
  .tx-type.approve { background: rgba(255,110,156,0.15); color: var(--accent3); }
  .tx-hash { color: var(--muted); flex: 1; }
  .tx-hash a { color: var(--accent2); text-decoration: none; }
  .tx-hash a:hover { text-decoration: underline; }
  .tx-gas { color: var(--muted); text-align: right; white-space: nowrap; }

  /* ── Gas analysis table ── */
  .gas-table { width: 100%; border-collapse: collapse; font-family: var(--mono); font-size: 12px; }
  .gas-table th {
    text-align: left;
    padding: 8px 12px;
    font-size: 10px;
    letter-spacing: 1.5px;
    color: var(--muted);
    border-bottom: 1px solid var(--border);
  }
  .gas-table td {
    padding: 10px 12px;
    border-bottom: 1px solid rgba(255,255,255,0.03);
    color: var(--text);
  }
  .gas-table tr:last-child td { border-bottom: none; }
  .gas-table .num { color: var(--accent2); text-align: right; }
  .gas-table .cost { color: var(--warn); text-align: right; }

  /* ── Status / toast ── */
  .toast {
    position: fixed;
    bottom: 32px;
    right: 32px;
    padding: 14px 20px;
    border-radius: var(--radius-sm);
    font-family: var(--mono);
    font-size: 12px;
    z-index: 1000;
    max-width: 400px;
    animation: toast-in 0.3s ease;
    border: 1px solid;
  }
  .toast.success { background: rgba(127,255,110,0.1); border-color: var(--accent); color: var(--accent); }
  .toast.error   { background: rgba(255,110,156,0.1); border-color: var(--accent3); color: var(--accent3); }
  .toast.pending { background: rgba(110,200,255,0.1); border-color: var(--accent2); color: var(--accent2); }
  @keyframes toast-in {
    from { opacity: 0; transform: translateY(10px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  /* ── Wallet info strip ── */
  .wallet-strip {
    display: flex; gap: 16px; align-items: center;
    font-family: var(--mono); font-size: 11px; color: var(--muted);
  }
  .wallet-strip .bal { color: var(--text); }

  /* ── Pool curve visual ── */
  .curve-wrap { position: relative; height: 120px; margin-top: 8px; }
  svg.curve { width: 100%; height: 100%; overflow: visible; }

  /* ── Responsive ── */
  @media (max-width: 900px) {
    .main { grid-template-columns: 1fr; }
    .full-width { grid-column: 1; }
    .stat-grid { grid-template-columns: repeat(2, 1fr); }
    .oracle-row { grid-template-columns: 1fr 1fr; }
  }
`;

// ─── Gas Data from transaction_log.txt ───────────────────────────────────────
const GAS_DATA = [
  { fn: "approve(TokenA)", gas: 46954 },
  { fn: "approve(TokenB)", gas: 46954 },
  { fn: "addLiquidity",    gas: 241848 },
  { fn: "swapAForB",       gas: 78428 },
  { fn: "swapBForA",       gas: 78450 },
  { fn: "removeLiquidity", gas: 82719 },
];
const ETH_GWEI   = 3;      // ~3 gwei base fee on Sepolia
const ETH_PRICE  = 3200;   // approximate ETH/USD reference

// ─── Bonding curve SVG ────────────────────────────────────────────────────────
function BondingCurve({ reserveA, reserveB }) {
  if (!reserveA || !reserveB || reserveA === 0n) return null;
  const k = Number(ethers.formatUnits(reserveA, 18)) * Number(ethers.formatUnits(reserveB, 18));
  const curX = Number(ethers.formatUnits(reserveA, 18));
  const curY = Number(ethers.formatUnits(reserveB, 18));
  const W = 300, H = 100;
  const xMin = curX * 0.3, xMax = curX * 2.5;
  const points = [];
  for (let i = 0; i <= 60; i++) {
    const x = xMin + (xMax - xMin) * (i / 60);
    const y = k / x;
    const px = ((x - xMin) / (xMax - xMin)) * W;
    const yMin = k / xMax, yMax = k / xMin;
    const py = H - ((y - yMin) / (yMax - yMin)) * H;
    if (py >= 0 && py <= H) points.push(`${px},${py}`);
  }
  const dotX = ((curX - xMin) / (xMax - xMin)) * W;
  const yMin2 = k / xMax, yMax2 = k / xMin;
  const dotY = H - ((curY - yMin2) / (yMax2 - yMin2)) * H;
  return (
    <svg className="curve" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      <polyline points={points.join(" ")} fill="none" stroke="rgba(127,255,110,0.4)" strokeWidth="1.5"/>
      <circle cx={dotX} cy={dotY} r="4" fill="var(--accent)" />
      <circle cx={dotX} cy={dotY} r="8" fill="none" stroke="rgba(127,255,110,0.3)" strokeWidth="1"/>
    </svg>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [provider, setProvider]   = useState(null);
  const [signer, setSigner]       = useState(null);
  const [account, setAccount]     = useState(null);
  const [contracts, setContracts] = useState(null);

  // Pool state
  const [reserveA, setReserveA]         = useState(null);
  const [reserveB, setReserveB]         = useState(null);
  const [priceAinB, setPriceAinB]       = useState(null);
  const [priceBinA, setPriceBinA]       = useState(null);
  const [totalLiq, setTotalLiq]         = useState(null);
  const [myLiquidity, setMyLiquidity]   = useState(null);
  const [balA, setBalA]                 = useState(null);
  const [balB, setBalB]                 = useState(null);

  // Oracle state
  const [oracleData, setOracleData] = useState(null);

  // UI state
  const [activeTab, setActiveTab]   = useState("swap");
  const [swapDir, setSwapDir]       = useState("AtoB");
  const [swapAmt, setSwapAmt]       = useState("");
  const [minOut, setMinOut]         = useState("");
  const [previewOut, setPreviewOut] = useState(null);

  const [addAmtA, setAddAmtA] = useState("");
  const [addAmtB, setAddAmtB] = useState("");
  const [remLiq, setRemLiq]   = useState("");

  const [txLog, setTxLog]   = useState([]);
  const [toast, setToast]   = useState(null);
  const [loading, setLoading] = useState(false);

  // ── Show toast ──────────────────────────────────────────────────────────────
  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 5000);
  };

  // ── Add to tx log ───────────────────────────────────────────────────────────
  const logTx = (type, hash, gasUsed) => {
    setTxLog(prev => [{
      type, hash,
      gasUsed: gasUsed ? Number(gasUsed).toLocaleString() : "—",
      ts: new Date().toLocaleTimeString()
    }, ...prev]);
  };

  // ── Connect wallet ──────────────────────────────────────────────────────────
  const connectWallet = async () => {
    if (!window.ethereum) { showToast("MetaMask not found", "error"); return; }
    try {
      const prov = new ethers.BrowserProvider(window.ethereum);
      await prov.send("eth_requestAccounts", []);
      const sign = await prov.getSigner();
      const addr = await sign.getAddress();

      const tokenA  = new ethers.Contract(ADDRESSES.tokenA,  ERC20_ABI,  sign);
      const tokenB  = new ethers.Contract(ADDRESSES.tokenB,  ERC20_ABI,  sign);
      const cpmm    = new ethers.Contract(ADDRESSES.cpmm,    CPMM_ABI,   sign);
      const oracle  = ADDRESSES.oracle !== "YOUR_ORACLE_ADDRESS_HERE"
        ? new ethers.Contract(ADDRESSES.oracle, ORACLE_ABI, prov)
        : null;

      setProvider(prov); setSigner(sign); setAccount(addr);
      setContracts({ tokenA, tokenB, cpmm, oracle });
      showToast(`Connected: ${shortAddr(addr)}`);
    } catch (e) { showToast(e.message, "error"); }
  };

  // ── Fetch pool state ────────────────────────────────────────────────────────
  const refresh = useCallback(async () => {
    if (!contracts) return;
    try {
      const [rA, rB]   = await contracts.cpmm.getReserves();
      const pAB        = await contracts.cpmm.getPriceAinB();
      const pBA        = await contracts.cpmm.getPriceBinA();
      const tLiq       = await contracts.cpmm.totalLiquidity();
      const bA         = await contracts.tokenA.balanceOf(account);
      const bB         = await contracts.tokenB.balanceOf(account);
      const myLiq      = account ? await contracts.cpmm.liquidityOf(account) : 0n;

      setReserveA(rA); setReserveB(rB);
      setPriceAinB(pAB); setPriceBinA(pBA);
      setTotalLiq(tLiq); setMyLiquidity(myLiq);
      setBalA(bA); setBalB(bB);

      if (contracts.oracle) {
        try {
          const snap = await contracts.oracle.getPriceComparisonView();
          setOracleData(snap);
        } catch (_) {}
      }
    } catch (e) { console.error(e); }
  }, [contracts, account]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => {
    const id = setInterval(refresh, 15000);
    return () => clearInterval(id);
  }, [refresh]);

  // ── Preview swap output ─────────────────────────────────────────────────────
  useEffect(() => {
    const calc = async () => {
      if (!contracts || !swapAmt || !reserveA || !reserveB) { setPreviewOut(null); return; }
      try {
        const amt = ethers.parseUnits(swapAmt, 18);
        const [rIn, rOut] = swapDir === "AtoB" ? [reserveA, reserveB] : [reserveB, reserveA];
        const out = await contracts.cpmm.getAmountOut(amt, rIn, rOut);
        setPreviewOut(out);
      } catch { setPreviewOut(null); }
    };
    calc();
  }, [swapAmt, swapDir, contracts, reserveA, reserveB]);

  // ── Approve helper ──────────────────────────────────────────────────────────
  const ensureApproval = async (token, amount, name) => {
    const allowance = await token.allowance(account, ADDRESSES.cpmm);
    if (allowance >= amount) return;
    showToast(`Approving ${name}…`, "pending");
    const tx = await token.approve(ADDRESSES.cpmm, ethers.MaxUint256);
    const receipt = await tx.wait();
    logTx("approve", tx.hash, receipt.gasUsed);
    showToast(`${name} approved ✓`);
  };

  // ── Swap ────────────────────────────────────────────────────────────────────
  const doSwap = async () => {
    if (!contracts || !swapAmt) return;
    setLoading(true);
    try {
      const amtIn  = ethers.parseUnits(swapAmt, 18);
      const minAmt = previewOut ? (previewOut * 95n) / 100n : 0n; // 5% slippage tolerance

      if (swapDir === "AtoB") {
        await ensureApproval(contracts.tokenA, amtIn, "TKA");
        showToast("Swapping A → B…", "pending");
        const tx = await contracts.cpmm.swapAForB(amtIn, minAmt);
        const r  = await tx.wait();
        logTx("swap", tx.hash, r.gasUsed);
        showToast(`Swapped ${swapAmt} TKA → ${fmt(previewOut)} TKB ✓`);
      } else {
        await ensureApproval(contracts.tokenB, amtIn, "TKB");
        showToast("Swapping B → A…", "pending");
        const tx = await contracts.cpmm.swapBForA(amtIn, minAmt);
        const r  = await tx.wait();
        logTx("swap", tx.hash, r.gasUsed);
        showToast(`Swapped ${swapAmt} TKB → ${fmt(previewOut)} TKA ✓`);
      }
      setSwapAmt(""); await refresh();
    } catch (e) { showToast(e.reason ?? e.message, "error"); }
    setLoading(false);
  };

  // ── Add liquidity ───────────────────────────────────────────────────────────
  const doAddLiquidity = async () => {
    if (!contracts || !addAmtA || !addAmtB) return;
    setLoading(true);
    try {
      const amtA = ethers.parseUnits(addAmtA, 18);
      const amtB = ethers.parseUnits(addAmtB, 18);
      await ensureApproval(contracts.tokenA, amtA, "TKA");
      await ensureApproval(contracts.tokenB, amtB, "TKB");
      showToast("Adding liquidity…", "pending");
      const tx = await contracts.cpmm.addLiquidity(amtA, amtB);
      const r  = await tx.wait();
      logTx("add", tx.hash, r.gasUsed);
      showToast("Liquidity added ✓");
      setAddAmtA(""); setAddAmtB(""); await refresh();
    } catch (e) { showToast(e.reason ?? e.message, "error"); }
    setLoading(false);
  };

  // ── Remove liquidity ────────────────────────────────────────────────────────
  const doRemoveLiquidity = async () => {
    if (!contracts || !remLiq) return;
    setLoading(true);
    try {
      const liq = ethers.parseUnits(remLiq, 18);
      showToast("Removing liquidity…", "pending");
      const tx = await contracts.cpmm.removeLiquidity(liq);
      const r  = await tx.wait();
      logTx("remove", tx.hash, r.gasUsed);
      showToast("Liquidity removed ✓");
      setRemLiq(""); await refresh();
    } catch (e) { showToast(e.reason ?? e.message, "error"); }
    setLoading(false);
  };

  // ── Gas analysis ─────────────────────────────────────────────────────────────
  const gasRows = GAS_DATA.map(d => {
    const ethCost = (d.gas * ETH_GWEI * 1e-9).toFixed(6);
    const usdCost = (parseFloat(ethCost) * ETH_PRICE).toFixed(4);
    return { ...d, ethCost, usdCost };
  });

  // ─── Render ─────────────────────────────────────────────────────────────────
  return (
    <>
      <style>{css}</style>

      {/* Header */}
      <header className="header">
        <div className="logo">
          CPMM<span>.</span>DEX
          <sub>Sepolia Testnet</sub>
        </div>
        <div style={{ display:"flex", gap:12, alignItems:"center" }}>
          {account && (
            <div className="wallet-strip">
              <span>{shortAddr(account)}</span>
              {balA !== null && <span className="bal">{fmt(balA,2)} TKA</span>}
              {balB !== null && <span className="bal">{fmt(balB,2)} TKB</span>}
            </div>
          )}
          <button
            className={`connect-btn ${account ? "connected" : ""}`}
            onClick={connectWallet}
          >
            {account ? shortAddr(account) : "CONNECT WALLET"}
          </button>
        </div>
      </header>

      <div className="main">

        {/* ── Pool Stats ── */}
        <div className="card full-width">
          <div className="card-title"><span className="dot" />POOL STATS</div>
          <div className="stat-grid">
            <div className="stat">
              <div className="stat-label">RESERVE A</div>
              <div className="stat-value green">{fmt(reserveA, 2)}</div>
              <div style={{fontSize:10,color:"var(--muted)",marginTop:4,fontFamily:"var(--mono)"}}>TKA</div>
            </div>
            <div className="stat">
              <div className="stat-label">RESERVE B</div>
              <div className="stat-value blue">{fmt(reserveB, 2)}</div>
              <div style={{fontSize:10,color:"var(--muted)",marginTop:4,fontFamily:"var(--mono)"}}>TKB</div>
            </div>
            <div className="stat">
              <div className="stat-label">PRICE A→B</div>
              <div className="stat-value">{fmt(priceAinB, 6)}</div>
              <div style={{fontSize:10,color:"var(--muted)",marginTop:4,fontFamily:"var(--mono)"}}>TKB per TKA</div>
            </div>
            <div className="stat">
              <div className="stat-label">MY LIQUIDITY</div>
              <div className="stat-value warn">{fmt(myLiquidity, 4)}</div>
              <div style={{fontSize:10,color:"var(--muted)",marginTop:4,fontFamily:"var(--mono)"}}>LP shares</div>
            </div>
          </div>
          {/* Bonding curve */}
          {reserveA && reserveB && reserveA > 0n && (
            <div className="curve-wrap" style={{marginTop:16}}>
              <div style={{fontSize:10,color:"var(--muted)",fontFamily:"var(--mono)",letterSpacing:1,marginBottom:4}}>
                x·y = k BONDING CURVE — current position ●
              </div>
              <BondingCurve reserveA={reserveA} reserveB={reserveB} />
            </div>
          )}
        </div>

        {/* ── Oracle ── */}
        <div className="card full-width">
          <div className="card-title"><span className="dot pink" />ORACLE — CHAINLINK ETH/USD vs AMM SPOT</div>
          {oracleData ? (
            <div className="oracle-row">
              <div className="oracle-stat">
                <div className="oracle-label">CHAINLINK PRICE</div>
                <div className="oracle-value" style={{color:"var(--accent2)"}}>
                  {fmtUSD(Number(ethers.formatUnits(oracleData.chainlinkPrice, 18)).toFixed(2))}
                </div>
              </div>
              <div className="oracle-stat">
                <div className="oracle-label">AMM SPOT PRICE</div>
                <div className="oracle-value" style={{color:"var(--accent)"}}>
                  {fmt(oracleData.ammSpotPrice, 6)}
                </div>
              </div>
              <div className="oracle-stat">
                <div className="oracle-label">DEVIATION</div>
                <div className="oracle-value" style={{color: oracleData.arbOpportunity ? "var(--accent3)" : "var(--warn)"}}>
                  {(Number(oracleData.deviationBps) / 100).toFixed(2)}%
                </div>
              </div>
              <div className={`arb-badge ${oracleData.arbOpportunity ? "active" : "inactive"}`}>
                {oracleData.arbOpportunity ? "⚡ ARB SIGNAL" : "✓ IN RANGE"}
              </div>
            </div>
          ) : (
            <div style={{fontFamily:"var(--mono)",fontSize:12,color:"var(--muted)"}}>
              {contracts?.oracle ? "Loading oracle data…" : "⚠ Deploy CPMMOracle.sol and update ADDRESSES.oracle to enable"}
            </div>
          )}
        </div>

        {/* ── Trading Panel ── */}
        <div className="card">
          <div className="card-title"><span className="dot blue" />TRADE</div>
          <div className="tabs">
            {["swap","liquidity"].map(t => (
              <button key={t} className={`tab ${activeTab===t?"active":""}`} onClick={() => setActiveTab(t)}>
                {t.toUpperCase()}
              </button>
            ))}
          </div>

          {activeTab === "swap" && (
            <>
              <div className="tabs" style={{marginBottom:14}}>
                <button className={`tab ${swapDir==="AtoB"?"active":""}`} onClick={() => setSwapDir("AtoB")}>TKA → TKB</button>
                <button className={`tab ${swapDir==="BtoA"?"active":""}`} onClick={() => setSwapDir("BtoA")}>TKB → TKA</button>
              </div>
              <div className="input-group">
                <div className="input-label">
                  AMOUNT IN
                  <span>BAL: {swapDir==="AtoB" ? fmt(balA,4) : fmt(balB,4)} {swapDir==="AtoB"?"TKA":"TKB"}</span>
                </div>
                <input type="number" placeholder="0.0" value={swapAmt} onChange={e => setSwapAmt(e.target.value)} />
              </div>
              <div className="preview">
                <span>YOU RECEIVE</span>
                <strong>{previewOut ? `${fmt(previewOut,6)} ${swapDir==="AtoB"?"TKB":"TKA"}` : "—"}</strong>
              </div>
              <div style={{fontSize:10,color:"var(--muted)",fontFamily:"var(--mono)",marginBottom:14}}>
                5% slippage tolerance · 0.3% swap fee
              </div>
              <button className="btn btn-blue" onClick={doSwap} disabled={!account || loading || !swapAmt}>
                {loading ? "PENDING…" : "SWAP"}
              </button>
            </>
          )}

          {activeTab === "liquidity" && (
            <>
              <div className="tabs" style={{marginBottom:14}}>
                <button className={`tab active`}>ADD</button>
              </div>
              <div className="input-group">
                <div className="input-label">TOKEN A AMOUNT<span>BAL: {fmt(balA,4)} TKA</span></div>
                <input type="number" placeholder="0.0" value={addAmtA} onChange={e => setAddAmtA(e.target.value)} />
              </div>
              <div className="input-group">
                <div className="input-label">TOKEN B AMOUNT<span>BAL: {fmt(balB,4)} TKB</span></div>
                <input type="number" placeholder="0.0" value={addAmtB} onChange={e => setAddAmtB(e.target.value)} />
              </div>
              <button className="btn btn-primary" onClick={doAddLiquidity} disabled={!account || loading || !addAmtA || !addAmtB}>
                {loading ? "PENDING…" : "ADD LIQUIDITY"}
              </button>

              <div style={{marginTop:20,paddingTop:20,borderTop:"1px solid var(--border)"}}>
                <div className="input-group">
                  <div className="input-label">LP SHARES TO BURN<span>OWNED: {fmt(myLiquidity,6)}</span></div>
                  <input type="number" placeholder="0.0" value={remLiq} onChange={e => setRemLiq(e.target.value)} />
                </div>
                <button className="btn btn-outline" onClick={doRemoveLiquidity} disabled={!account || loading || !remLiq}>
                  {loading ? "PENDING…" : "REMOVE LIQUIDITY"}
                </button>
              </div>
            </>
          )}
        </div>

        {/* ── Transaction Log ── */}
        <div className="card">
          <div className="card-title"><span className="dot warn" />TRANSACTION LOG</div>
          {txLog.length === 0 ? (
            <div style={{fontFamily:"var(--mono)",fontSize:12,color:"var(--muted)"}}>No transactions yet this session.</div>
          ) : (
            <div className="tx-feed">
              {txLog.map((tx, i) => (
                <div className="tx-item" key={i}>
                  <span className={`tx-type ${tx.type}`}>{tx.type.toUpperCase()}</span>
                  <span className="tx-hash">
                    <a href={`https://sepolia.etherscan.io/tx/${tx.hash}`} target="_blank" rel="noreferrer">
                      {shortAddr(tx.hash)}
                    </a>
                    <span style={{color:"var(--muted)",marginLeft:8}}>{tx.ts}</span>
                  </span>
                  <span className="tx-gas">{tx.gasUsed} gas</span>
                </div>
              ))}
            </div>
          )}
          <button className="btn btn-outline" style={{marginTop:12}} onClick={refresh}>↻ REFRESH POOL</button>
        </div>

        {/* ── Gas Analysis ── */}
        <div className="card full-width">
          <div className="card-title"><span className="dot" />GAS ANALYSIS — SEPOLIA TRANSACTIONS</div>
          <div style={{fontSize:10,color:"var(--muted)",fontFamily:"var(--mono)",marginBottom:16}}>
            Reference: {ETH_GWEI} gwei base fee · ETH/USD ≈ ${ETH_PRICE.toLocaleString()}
          </div>
          <table className="gas-table">
            <thead>
              <tr>
                <th>FUNCTION</th>
                <th style={{textAlign:"right"}}>GAS UNITS</th>
                <th style={{textAlign:"right"}}>ETH COST</th>
                <th style={{textAlign:"right"}}>USD COST</th>
                <th style={{textAlign:"right"}}>TX HASH</th>
              </tr>
            </thead>
            <tbody>
              {gasRows.map((r, i) => (
                <tr key={i}>
                  <td style={{fontFamily:"var(--mono)"}}>{r.fn}</td>
                  <td className="num">{r.gas.toLocaleString()}</td>
                  <td className="num">{r.ethCost} ETH</td>
                  <td className="cost">{fmtUSD(r.usdCost)}</td>
                  <td style={{textAlign:"right",fontFamily:"var(--mono)",fontSize:11}}>
                    {GAS_DATA[i] && (
                      <a href={`https://sepolia.etherscan.io/tx/${[
                        "0xa683c14440792a6489aee78c54caf742a6d2392e43e714510002261035c1db0e",
                        "0x8112150b3c1197c56038a4d69d8e5cbd70f81080d9237a7482243258d6744856",
                        "0xa4c4992c73887b323171fcccdb5c057698cc22a7de567bbbbfa79015b36d3326",
                        "0x780b6f80286653d7c9a825c23849efa7bcfd4cbcf8ad6a06c0600050c494c60d",
                        "0x34b37003d4c04431543bb7a1d5d372f54ff31faaf21acbbb95fb4606cae26f11",
                        "0xa8d20945259798e96d0b17b1722829799a4a637546b744931f1a3ed61e66e468"
                      ][i]}`} target="_blank" rel="noreferrer"
                        style={{color:"var(--accent2)",textDecoration:"none"}}>
                        {shortAddr([
                          "0xa683c14440792a6489aee78c54caf742a6d2392e43e714510002261035c1db0e",
                          "0x8112150b3c1197c56038a4d69d8e5cbd70f81080d9237a7482243258d6744856",
                          "0xa4c4992c73887b323171fcccdb5c057698cc22a7de567bbbbfa79015b36d3326",
                          "0x780b6f80286653d7c9a825c23849efa7bcfd4cbcf8ad6a06c0600050c494c60d",
                          "0x34b37003d4c04431543bb7a1d5d372f54ff31faaf21acbbb95fb4606cae26f11",
                          "0xa8d20945259798e96d0b17b1722829799a4a637546b744931f1a3ed61e66e468"
                        ][i])}
                      </a>
                    )}
                  </td>
                </tr>
              ))}
              <tr style={{borderTop:"1px solid var(--border2)"}}>
                <td style={{fontFamily:"var(--mono)",color:"var(--muted)"}}>TOTAL</td>
                <td className="num">{gasRows.reduce((s,r)=>s+r.gas,0).toLocaleString()}</td>
                <td className="num">{gasRows.reduce((s,r)=>s+parseFloat(r.ethCost),0).toFixed(6)} ETH</td>
                <td className="cost">{fmtUSD(gasRows.reduce((s,r)=>s+parseFloat(r.usdCost),0).toFixed(4))}</td>
                <td />
              </tr>
            </tbody>
          </table>
        </div>

      </div>

      {/* Toast */}
      {toast && <div className={`toast ${toast.type}`}>{toast.msg}</div>}
    </>
  );
}
